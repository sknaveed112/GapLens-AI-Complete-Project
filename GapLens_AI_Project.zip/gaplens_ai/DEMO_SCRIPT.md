# GapLens AI — 3-minute hackathon demo script

## Before the demo
- Start the Flask app and open `http://127.0.0.1:5000`.
- Decide whether you are demonstrating AI API mode or DEMO HEURISTIC mode.
- Prepare two or three genuine public sources on one topic, preferably official notices. If using the sample data, clearly say it is illustrative.
- Never show your `.env` file or API key.

## 0:00–0:25 — Problem
"People often find information across different websites, but search results and summaries do not always reveal what is missing, whether two sources disagree, or what is outdated. GapLens AI is designed to help users review those information gaps."

## 0:25–0:55 — Input
"I will enter one research question and add multiple sources. The sources can be public URLs or text pasted by the user. Each source gets an ID so findings can point back to evidence."

## 0:55–1:35 — Analysis
"Now I run the analysis. GapLens organizes source summaries, potential gaps, possible conflicts, and date-related signals. We deliberately label these as signals, not guaranteed facts."

## 1:35–2:15 — Evidence
"Here is a finding and its source reference. A judge or user can open the original page and check the context. This evidence trail is important: the system should not ask users to trust an AI answer blindly."

## 2:15–2:40 — Next steps
"The verification checklist turns the analysis into actions: check the latest official notice, compare conflicting details, and confirm dates and required documents."

## 2:40–3:00 — Close
"GapLens AI goes beyond summarization by focusing on what may be missing and what should be verified next. Its purpose is to make research more transparent and evidence-led."

## Important honesty note
If using DEMO HEURISTIC mode, say:
"This run uses a lightweight offline heuristic to demonstrate the workflow. It is not semantic AI. AI API mode is available when a provider key is configured."

Do not claim that the prototype proves factual completeness, verifies every claim, or guarantees the correctness of AI findings.
