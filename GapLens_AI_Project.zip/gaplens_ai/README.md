# GapLens AI — Intelligent Research Verification System

**SHINCHAN ONLINE HACKATHON 2026 | DEVENGERS problem statement**

> Find what's missing. Detect what's conflicting. Verify what matters.

GapLens AI is a web application that reviews multiple user-provided sources against a research question. It organizes source summaries, potential information gaps, possible conflicts, date signals, and a prioritized verification checklist.

## 1. Problem and solution

Online information can be scattered, incomplete, inconsistent, or outdated. Ordinary search and summarization do not necessarily tell a user what has not been covered or what needs checking.

GapLens AI helps users:
- enter a research question or goal;
- collect readable text from public URLs or paste source text;
- review source summaries;
- flag potential gaps and possible contradictions;
- surface date-related signals;
- inspect source references; and
- work through a verification checklist.

## 2. Technology

- Frontend: HTML5, CSS3, Vanilla JavaScript
- Backend: Python 3 + Flask
- Extraction: Requests + BeautifulSoup
- AI: OpenAI-compatible Chat Completions API (configurable by environment variables)
- Offline demo: transparent heuristic fallback when no API key is configured

## 3. Run locally

### Requirements
Python 3.10 or newer is recommended.

### Setup
```bash
# 1. Extract the project ZIP and enter its folder
cd gaplens_ai

# 2. Create a virtual environment
python -m venv .venv

# Windows PowerShell:
.venv\Scripts\Activate.ps1

# macOS / Linux:
source .venv/bin/activate

# 3. Install packages
pip install -r requirements.txt

# 4. Create your local environment file
# Windows:
copy .env.example .env
# macOS / Linux:
cp .env.example .env

# 5. Start the server
python app.py
```
Open **http://127.0.0.1:5000** in your browser.

The app works in DEMO HEURISTIC mode without an API key. This mode is useful for testing the workflow, but it is not semantic AI analysis.

## 4. Enable AI API mode

1. Open `.env` in a text editor.
2. Set `OPENAI_API_KEY` to your own API key.
3. Keep `OPENAI_BASE_URL=https://api.openai.com/v1`, or use a compatible provider endpoint.
4. Set `OPENAI_MODEL` to a model available to your account.
5. Restart the Flask server.

**Never commit `.env` or expose an API key in frontend JavaScript, screenshots, GitHub, or a public demo.** API use may incur provider charges. The backend sends the research question and source excerpts to the configured provider when AI mode is enabled.

## 5. Demo flow

1. Enter: `What should a student verify before applying for this scholarship?`
2. Add two or more sources using public URLs, or paste sample text.
3. Select **Analyze information gaps**.
4. Review potential gaps, possible conflicts, date signals, and checklist.
5. Open the original source references and explain what still needs human verification.

Use real official sources for a live presentation, or clearly label any sample material as illustrative.

## 6. Architecture

```text
Browser (HTML / CSS / JavaScript)
          |
          | JSON requests
          v
Flask application (app.py)
     |                 |
     v                 v
URL text extractor   AI provider
     |                 |
     +--------+--------+
              |
              v
     Structured analysis JSON
              |
              v
Dashboard: gaps / conflicts / dates / checklist / sources
```

## 7. Responsible-use and limitations

- Findings are **potential signals**, not guaranteed facts.
- The heuristic fallback uses simple keyword and pattern checks. It can miss semantic gaps and nuanced contradictions.
- AI output can be incomplete or incorrect. Verify every important claim against the original source.
- URL collection supports public HTML/text pages only; some websites block automated access or render content with JavaScript.
- This prototype does not crawl entire websites, authenticate to private sites, or certify source credibility.
- Do not submit confidential, personal, or sensitive information.
- The URL collector rejects private/local IP destinations and does not follow redirects in this demo. Deployments should add stronger network egress controls, rate limiting, authentication, logging controls, and tests.

## 8. Suggested next improvements

- PDF upload and extraction
- source publication-date extraction
- claim-level evidence highlighting
- export report to PDF
- user accounts and saved research sessions
- stronger contradiction detection with claim extraction
- test suite and deployment pipeline

## 9. Repository structure

```text
gaplens_ai/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   └── js/app.js
└── data/
    └── demo_sources.txt
```

## 10. Hackathon alignment

The project directly addresses the supplied challenge: analyze multiple sources, summarize information, identify potential gaps and conflicts, flag date signals, provide source references, and guide users on what to verify next.

The prototype should be demonstrated with real or clearly identified sample sources. A generic chatbot or summary-only demo is not the intended submission.
