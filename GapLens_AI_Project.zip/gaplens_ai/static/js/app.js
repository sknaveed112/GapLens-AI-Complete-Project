const sources = [];
const $ = (id) => document.getElementById(id);
function toast(message){const t=$("toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2800)}
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function updateSources(){
  $("sourceCount").textContent=`${sources.length} SOURCE${sources.length===1?"":"S"}`;
  if(!sources.length){$("sourceList").innerHTML='<div class="empty-source">Your collected sources will appear here.</div>';return}
  $("sourceList").innerHTML=sources.map((s,i)=>`<div class="source-item"><div class="source-icon">↗</div><div class="source-meta"><b>${escapeHtml(s.title)}</b><small>${escapeHtml(s.url||"Pasted source")} · ${s.text.length.toLocaleString()} chars</small></div><button class="remove-source" data-remove="${i}" aria-label="Remove source">×</button></div>`).join("");
  document.querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{sources.splice(Number(b.dataset.remove),1);updateSources()}));
}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===btn));
  $("urlPane").classList.toggle("hidden",btn.dataset.tab!=="url");
  $("textPane").classList.toggle("hidden",btn.dataset.tab!=="text");
}));
$("fetchBtn").addEventListener("click",async()=>{
  const urls=$("urlInput").value.split(/\n/).map(x=>x.trim()).filter(Boolean);
  if(!urls.length){toast("Paste at least one public URL.");return}
  if(urls.length>6){toast("Maximum 6 URLs per collection.");return}
  $("fetchBtn").disabled=true;$("fetchBtn").textContent="Collecting...";
  try{
    const res=await fetch("/api/fetch",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({urls})});
    const data=await res.json();if(!res.ok)throw new Error(data.error||"Could not collect URLs");
    data.sources.forEach(s=>{if(sources.length<8)sources.push(s)});
    updateSources();
    if(data.errors.length)toast(`${data.sources.length} collected; ${data.errors.length} URL(s) need attention.`);
    else toast(`${data.sources.length} source(s) collected.`);
  }catch(e){toast(e.message)}finally{$("fetchBtn").disabled=false;$("fetchBtn").textContent="＋ Collect page text"}
});
$("addTextBtn").addEventListener("click",()=>{
  const text=$("sourceText").value.trim();if(text.length<30){toast("Paste at least 30 characters of source text.");return}
  if(sources.length>=8){toast("Maximum 8 sources.");return}
  sources.push({title:$("sourceTitle").value.trim()||`Pasted source ${sources.length+1}`,url:$("sourceUrl").value.trim(),text});
  $("sourceTitle").value="";$("sourceUrl").value="";$("sourceText").value="";updateSources();toast("Source added.");
});
function sourceLink(id, allSources){
  const s=allSources.find(x=>x.id===id);return s&&s.url?`<a class="source-ref" href="${escapeHtml(s.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(id)} ↗</a>`:`<span class="source-ref">${escapeHtml(id)}</span>`;
}
function renderReport(data){
  const all=data.sources||[];
  const gaps=data.potential_gaps||[], conflicts=data.possible_conflicts||[], outdated=data.outdated_signals||[];
  let html=`<div class="report-head"><b>Analysis complete</b><span class="mode">${escapeHtml(data.mode||"ANALYSIS")}</span></div>
  <p class="report-overview">${escapeHtml(data.overview||"Review the signals below.")}</p>
  <div class="metric-row"><div class="metric"><b>${gaps.length}</b><small>POTENTIAL GAPS</small></div><div class="metric"><b>${conflicts.length}</b><small>CONFLICT SIGNALS</small></div><div class="metric"><b>${outdated.length}</b><small>DATE SIGNALS</small></div></div>`;
  html+=`<section class="report-section"><h3>✦ Potential information gaps</h3>`;
  html+=gaps.length?gaps.map(g=>`<div class="report-card"><b>${escapeHtml(g.gap)}</b><p>${escapeHtml(g.why_it_matters||"Review this topic against an authoritative source.")}</p><p><strong>Verify next:</strong> ${escapeHtml(g.verify_next||"Find supporting evidence.")}</p>${(g.evidence||[]).map(id=>sourceLink(id,all)).join("")}</div>`).join(""):`<div class="report-card"><p>No explicit gap signal returned. This does not prove completeness.</p></div>`;
  html+=`</section><section class="report-section"><h3>⇄ Possible conflicts</h3>`;
  html+=conflicts.length?conflicts.map(c=>`<div class="report-card"><span class="severity">${escapeHtml((c.severity||"REVIEW").toUpperCase())}</span><b>${escapeHtml(c.title)}</b><p>${escapeHtml(c.details)}</p>${(c.evidence||[]).map(id=>sourceLink(id,all)).join("")}</div>`).join(""):`<div class="report-card"><p>No conflict signal detected in the supplied material. Automated checks can miss contradictions.</p></div>`;
  html+=`</section><section class="report-section"><h3>◷ Outdated or date signals</h3>`;
  html+=outdated.length?outdated.map(o=>`<div class="report-card"><b>${escapeHtml(o.source_id||"Source")}</b><p>${escapeHtml(o.reason||("Years found: "+(o.years_found||[]).join(", ")))}</p>${sourceLink(o.source_id,all)}</div>`).join(""):`<div class="report-card"><p>No clear outdated signal was returned. Always check the publication or update date on the original page.</p></div>`;
  html+=`</section><section class="report-section"><h3>✓ Your verification checklist</h3>`;
  html+=(data.verification_checklist||[]).map(item=>`<label class="check"><input type="checkbox"><span>${escapeHtml(item)}</span></label>`).join("");
  html+=`</section><section class="report-section"><h3>Source review</h3>`;
  html+=all.map(s=>`<div class="report-card"><b>${escapeHtml(s.id)} · ${escapeHtml(s.title)}</b><p>${escapeHtml(s.url||"User-provided text")}</p>${s.url?`<a class="source-ref" href="${escapeHtml(s.url)}" target="_blank" rel="noopener noreferrer">Open original source ↗</a>`:""}</div>`).join("");
  html+=`<div class="disclaimer">${escapeHtml(data.disclaimer||"Review all results against original sources.")} ${escapeHtml(data.confidence_note||"")}</div>`;
  $("report").innerHTML=html;$("emptyReport").classList.add("hidden");$("loading").classList.add("hidden");$("report").classList.remove("hidden");
}
$("analyzeBtn").addEventListener("click",async()=>{
  const question=$("question").value.trim();if(question.length<8){toast("Enter a more specific research question.");return}
  if(!sources.length){toast("Add at least one source first.");return}
  $("emptyReport").classList.add("hidden");$("report").classList.add("hidden");$("loading").classList.remove("hidden");$("analyzeBtn").disabled=true;
  try{
    const res=await fetch("/api/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({question,sources})});
    const data=await res.json();if(!res.ok)throw new Error(data.error||"Analysis failed");
    renderReport(data);
  }catch(e){$("loading").classList.add("hidden");$("emptyReport").classList.remove("hidden");toast(e.message)}
  finally{$("analyzeBtn").disabled=false}
});
updateSources();